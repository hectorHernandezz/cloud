<?php $__env->startSection('content'); ?>

    <div class="container">


      <section class="common-box">
      <div class="container">

        <div class="row main">
             <div class="content-header-2">
                <h3 class="text-center">My Personal Info</h3>
              </div>
            <div class="main-content-2 row">
                <div class=" userinfoheader">
                <?php if(Auth::user()->img_photo == NULL): ?>
                                <img src="img_photo/unknown.png" alt="User Avatar" class="img-circle" />
                            <?php else: ?>
                                <img src="<?php echo e(Auth::user()->img_photo); ?>" alt="User Avatar" class="img-circle" />
                            <?php endif; ?>  
                <h1><?php echo e(Auth::user()->name); ?></h1>
                </div>
                <form action="#" method="POST" enctype="multipart/form-data">
                  <div class="col-xs-12 col-sm-9">
                    <div class="input-group">
                      <span class="input-group-addon"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
                      <input id="username" type="text" class="form-control" name="username" placeholder="Enter your UserName" value="<?php echo e(Auth::user()->username); ?>">
                    </div>
                    <div class="input-group">
                      <span class="input-group-addon"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
                      <input id="name" type="text" class="form-control" name="name" placeholder="Enter your Full Name" value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                    <div class="input-group">
                      <span class="input-group-addon"><span class="glyphicon glyphicon-upload" aria-hidden="true"></span></span>
                      <input type="file" id="msgimg" class="form-control" name="msgimg" placeholder="Choose your Image File">
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-3">
                    <div class="form-group sendbtn-area">
                        <input type="submit" class="btn btn-success btn-lg btn-block restricted-button" name="btnSend" value="Save">
                    </div>
                  </div>
                </form>                   
            </div>
        </div>


        <div class="row main">
             <div class="content-header-2">
                <h3 class="text-center">Friendship Requests</h3>
              </div>
            <div class="content-subheader-2 row">
                <ul class="pagination pagination-lg">
                  <li class="active"><a href="#">1</a></li>
                </ul>
            </div>
            <div class="main-content-2">
                    <ul class="chat">
                       <li class="left clearfix"><span class="chat-img pull-left">
                            <?php if(Auth::user()->img_photo == NULL): ?>
                                <img src="img_photo/unknown.png" alt="User Avatar" class="img-circle" />
                            <?php else: ?>
                                <img src="<?php echo e(Auth::user()->img_photo); ?>" alt="User Avatar" class="img-circle" />
                            <?php endif; ?> 
                        </span>
                            <div class="userlist-body clearfix">
                                <div class="header headername">
                                    <strong class="primary-font">Antonieta FalsePatel</strong>
                                </div>
                                <div class="buttonRight">
                                    <a href="profile.html" type="button"  class="btn btn-md btn-info"><span class="glyphicon glyphicon-option-horizontal"></span></a>
                                    <button type="button" class="btn btn-md btn-success">
                                      <span class="glyphicon glyphicon-plus"></span>
                                    </button>
                                </div>
                            </div>
                        </li>                      

             </ul>
            </div>
          </div>


        <div class="row main">
             <div class="content-header-2">
                <h3 class="text-center">My Friends</h3>
              </div>
            <div class="content-subheader-2 row">
                <ul class="pagination pagination-lg">
                  <li><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li class="active"><a href="#">4</a></li>
                </ul>
            </div>
            <div class="main-content-2">
            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="chat">
                       <li class="left clearfix"><span class="chat-img pull-left">
                            <?php if($friend->img_photo == NULL): ?>
                                <img src="img_photo/unknown.png" alt="User Avatar" class="img-circle" />
                            <?php else: ?>
                                <img src="<?php echo e($friend->img_photo); ?>" alt="User Avatar" class="img-circle" />
                            <?php endif; ?> 
                        </span>
                            <div class="userlist-body clearfix">
                                <div class="header headername">
                                    <strong class="primary-font"><?php echo e($friend->name); ?></strong>
                                </div>
                                <div class="buttonRight">
                                    <a href="profile.html" type="button"  class="btn btn-md btn-info"><span class="glyphicon glyphicon-option-horizontal"></span></a>
                                    <button type="button" class="btn btn-md btn-danger">
                                      <span class="glyphicon glyphicon-minus"></span>
                                    </button>
                                </div>
                            </div>
                        </li>
             </ul>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </div>
          </div>
      </div>
      </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>