<?php $__env->startSection('content'); ?>

<div class="container">


      <section class="common-box">
      <div class="container">
        <div class="row main">
             <div class="content-header-2">
                <h3 class="text-center">Users Search</h3>
              </div>
            <div class="content-subheader-2 row">
                <form action="#" method="GET">
                  <div class="col-xs-12 col-sm-9">
                    <div class="input-group">
                      <span class="input-group-addon"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
                      <input id="username" type="text" class="form-control" name="username" placeholder="Enter UserName Filter">
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-3">
                    <div class="form-group searchbtn-area-sm">
                        <input type="submit" class="btn btn-primary btn-lg btn-block restricted-button" name="btnSend" value="Search">
                    </div>
                  </div>
                </form>   
            </div>
            <div class="content-subheader-2 row">
                <ul class="pagination pagination-lg">
                  <?php echo e($users->links()); ?>

                </ul>
            </div>
            <div class="main-content-2">
                    <ul class="chat">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li class="left clearfix"><span class="chat-img pull-left">
                            <?php if($user->img_photo == NULL): ?>
                                <img src="img_photo/unknown.png" alt="User Avatar" class="img-circle" />
                            <?php else: ?>
                                <img src="<?php echo e($user->img_photo); ?>" alt="User Avatar" class="img-circle" />
                            <?php endif; ?>
                        </span>
        

                            <div class="userlist-body clearfix">
                                <div class="header headername">
                                    <strong class="primary-font"><?php echo e($user->name); ?></strong>
                                </div>
                                <div class="buttonRight">
                                    <a href="profile.html" type="button"  class="btn btn-md btn-info"><span class="glyphicon glyphicon-option-horizontal"></span></a>
                                    
                                        <button type="button" class="btn btn-md btn-success">
                                          <span class="glyphicon glyphicon-plus"></span>
                                        </button>
                                    
                                </div>
                            </div>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </ul>
            </div>
          </div>
      </div>
      </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>